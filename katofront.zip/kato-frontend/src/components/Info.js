import React, {Component} from "react";
import './Info.css';
import { Bar, Line } from 'react-chartjs-2';
import axios from "axios";
import { element } from "prop-types";


class Info extends Component {
    constructor(props) {
        super(props);
       
        //console.log("props", this.props);

        this.state = {
            // parentId: props.location.aboutParent.parentId,
            // firstName: props.location.aboutParent.firstName,
            // lastName: props.location.aboutParent.lastName,
            // studentList : []

            name: "",
            users:[],
            students: [],
            parents: [],
            studyTime: [],
            atpq: [],
            scores: [],
            parent_id: this.props.location.aboutParent,
            student_id: "104",
            skills: 75,
            prog: 12,
            study:6,
            avg: 3

        }

        console.log("pid", this.state.parent_id)
    
        

        this.changeWeek1 = this.changeWeek1.bind(this);
        this.changeWeek2 = this.changeWeek2.bind(this);
        this.changeWeek3 = this.changeWeek3.bind(this);
        this.changeWeek4 = this.changeWeek4.bind(this);
        this.changeWeek5 = this.changeWeek5.bind(this);
        this.secondsToMinutes = this.secondsToMinutes.bind(this);
        this.overView = this.overView.bind(this);
        this.setId = this.setId.bind(this);
        this.setName = this.setName.bind(this);
        this.setId(this.state.parent_id)
        this.setName();

        console.log("uid", this.state.student_id)
    }


    setId(id){
        console.log("id", id)
           
        const uid = "";
               fetch("http://localhost:3000/parent").then(res => res.json()).then(res => res.forEach(element => {if(element.user_id === id.parentId) this.setState({student_id: element.student_id})}))

                
            
            
        //{var response = res.data.filter(val => val.user_id === id)}
    }

    setName(){
        const val = this.state.student_id;
        if(val === 104){
            this.setState({
                name: "Jimmy"
            })
        }
        if (val === 105) {
            this.setState({
                name: "Rakesh"
            })

        } 
        if (val === 106){
            this.setState({
                name: "Rabiga"
            })

        }
        this.forceUpdate()
    }

    componentDidMount() {

        this.setName()
        this.setState({
            atpq:[0,3]
        })

        
        fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-09-17T19:15:27.000Z&date2=2019-09-24T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({studyTime: [0, this.secondsToMinutes(res[0].avg)]}));
        fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-09-17T19:15:27.000Z&date2=2019-09-24T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({scores: [0, res[0].avg/100]}));

    }

    secondsToMinutes(input){
        return input / 60;
    }



    changeWeek1() {
        this.setName()
        console.log("studentid: " + this.state.student_id)
        this.setState({
            studyTime: [],
            scores: [],
            atpq: [0, 4],
            avg: 3
        })

        
        fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-08-24T19:15:27.000Z&date2=2019-09-01T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({studyTime: [0, this.secondsToMinutes(res[0].avg)]}));
        fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-08-24T19:15:27.000Z&date2=2019-09-01T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({scores: [0, res[0].avg/100]}));
        
        fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-08-24T19:15:27.000Z&date2=2019-09-01T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({skills: Math.trunc(res[0].avg)}));
        fetch("http://localhost:3000/totalques?uid="+ this.state.student_id +"&date1=2019-08-24T19:15:27.000Z&date2=2019-09-01T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({prog: Math.trunc(res[0].sum * 1000)}));
        fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-08-24T19:15:27.000Z&date2=2019-09-01T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({study: Math.trunc(this.secondsToMinutes(res[0].avg))}));

       
    }

    changeWeek2() {
        this.setName()
        const query = "uid" + {} + "&date1=2019-09-01T19:15:27.000Z&date2=2019-09-08T19:15:27.000Z";
        this.setState({
            studyTime: [],
            scores: [],
            atpq: [4,2],
            avg: 2
        })
        Promise.all(
            [
                fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-08-24T19:15:27.000Z&date2=2019-09-01T19:15:27.000Z"),
                fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-09-01T19:15:27.000Z&date2=2019-09-08T19:15:27.000Z")
            ]
        ).then((response) => ([response[0].json(), response[1].json()])).then((response) => {response[0].then(res=> this.setState({studyTime: this.state.studyTime.concat(this.secondsToMinutes(res[0].avg))}));response[1].then(res => this.setState({studyTime: this.state.studyTime.concat(this.secondsToMinutes(res[0].avg))}))})
        
        Promise.all(
            [
                fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-08-24T19:15:27.000Z&date2=2019-09-01T19:15:27.000Z"),
                fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-09-01T19:15:27.000Z&date2=2019-09-08T19:15:27.000Z")
            ]
        ).then((response) => ([response[0].json(), response[1].json()])).then((response) => {response[0].then(res=> this.setState({scores: this.state.scores.concat(res[0].avg/100)}));response[1].then(res => this.setState({scores: this.state.scores.concat(res[0].avg/100)}))})
        
        fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-09-01T19:15:27.000Z&date2=2019-09-08T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({skills: Math.trunc(res[0].avg)}));
        fetch("http://localhost:3000/totalques?uid="+ this.state.student_id +"&date1=2019-09-01T19:15:27.000Z&date2=2019-09-08T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({prog: Math.trunc(res[0].sum * 1000)}));
        fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-09-01T19:15:27.000Z&date2=2019-09-08T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({study: Math.trunc(this.secondsToMinutes(res[0].avg))}));
    
        
      
    }

    changeWeek3() {
        this.setName()
        const query = "uid" + {} + "&date1=2019-09-08T19:15:27.000Z&date2=2019-09-17T19:15:27.000Z";
        this.setState({
            studyTime: [],
            scores: [],
            atpq: [2,3],
            avg: 4
        })
        Promise.all(
            [
                fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-09-01T19:15:27.000Z&date2=2019-09-08T19:15:27.000Z"),
                fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-09-08T19:15:27.000Z&date2=2019-09-17T19:15:27.000Z")
            ]
        ).then((response) => ([response[0].json(), response[1].json()])).then((response) => {response[0].then(res=> this.setState({studyTime: this.state.studyTime.concat(this.secondsToMinutes(res[0].avg))}));response[1].then(res => this.setState({studyTime: this.state.studyTime.concat(this.secondsToMinutes(res[0].avg))}))})
            
        Promise.all(
            [
                fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-09-01T19:15:27.000Z&date2=2019-09-08T19:15:27.000Z"),
                fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-09-08T19:15:27.000Z&date2=2019-09-17T19:15:27.000Z")
            ]
        ).then((response) => ([response[0].json(), response[1].json()])).then((response) => {response[0].then(res=> this.setState({scores: this.state.scores.concat(res[0].avg/100)}));response[1].then(res => this.setState({scores: this.state.scores.concat(res[0].avg/100)}))})
            
        fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-09-08T19:15:27.000Z&date2=2019-09-17T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({skills: Math.trunc(res[0].avg)}));
        fetch("http://localhost:3000/totalques?uid="+ this.state.student_id +"&date1=2019-09-08T19:15:27.000Z&date2=2019-09-17T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({prog: Math.trunc(res[0].sum * 1000)}));
        fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-09-08T19:15:27.000Z&date2=2019-09-17T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({study: Math.trunc(this.secondsToMinutes(res[0].avg))}));
   
     
    }

    changeWeek4() {
      //  console.log(4);
      this.setName()
        const query = "uid" + {} + "&date1=2019-09-17T19:15:27.000Z&date2=2019-09-24T19:15:27.000Z";
        this.setState({
            studyTime: [],
            scores: [],
            atpq: [3,3],
            avg: 2
        })
        Promise.all(
            [
                fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-09-08T19:15:27.000Z&date2=2019-09-17T19:15:27.000Z"),
                fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-09-17T19:15:27.000Z&date2=2019-09-24T19:15:27.000Z")
            ]
        ).then((response) => ([response[0].json(), response[1].json()])).then((response) => {response[0].then(res=> this.setState({studyTime: this.state.studyTime.concat(this.secondsToMinutes(res[0].avg))}));response[1].then(res => this.setState({studyTime: this.state.studyTime.concat(this.secondsToMinutes(res[0].avg))}))})
        
        Promise.all(
            [
                fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-09-08T19:15:27.000Z&date2=2019-09-17T19:15:27.000Z"),
                fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-09-17T19:15:27.000Z&date2=2019-09-24T19:15:27.000Z")
            ]
        ).then((response) => ([response[0].json(), response[1].json()])).then((response) => {response[0].then(res=> this.setState({scores: this.state.scores.concat(res[0].avg/100)}));response[1].then(res => this.setState({scores: this.state.scores.concat(res[0].avg/100)}))})
           
        fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-09-17T19:15:27.000Z&date2=2019-09-24T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({skills: Math.trunc(res[0].avg)}));
        fetch("http://localhost:3000/totalques?uid="+ this.state.student_id +"&date1=2019-09-17T19:15:27.000Z&date2=2019-09-24T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({prog: Math.trunc(res[0].sum * 1000)}));
        fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-09-17T19:15:27.000Z&date2=2019-09-24T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({study: Math.trunc(this.secondsToMinutes(res[0].avg))}));
   
    }

    changeWeek5() {
       // console.log(5);
       this.setName()
       console.log("name", this.state.name)
        const query = "uid" + {} + "&date1=2019-09-24T19:15:27.000Z&date2=2019-10-26T19:15:27.000Z";
        this.setState({
            studyTime: [],
            scores: [],
            atpq: [3,4],
            avg: 3
        })
        Promise.all(
            [
                fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-09-17T19:15:27.000Z&date2=2019-09-24T19:15:27.000Z"),
                fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-09-24T19:15:27.000Z&date2=2019-10-26T19:15:27.000Z")
            ]
        ).then((response) => ([response[0].json(), response[1].json()])).then((response) => {response[0].then(res=> this.setState({studyTime: this.state.studyTime.concat(this.secondsToMinutes(res[0].avg))}));response[1].then(res => this.setState({studyTime: this.state.studyTime.concat(this.secondsToMinutes(res[0].avg))}))})
           
        Promise.all(
            [
                fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-09-17T19:15:27.000Z&date2=2019-09-24T19:15:27.000Z"),
                fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-09-24T19:15:27.000Z&date2=2019-10-26T19:15:27.000Z")
            ]
        ).then((response) => ([response[0].json(), response[1].json()])).then((response) => {response[0].then(res=> this.setState({scores: this.state.scores.concat(res[0].avg/100)}));response[1].then(res => this.setState({scores: this.state.scores.concat(res[0].avg/100)}))})

        fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-09-24T19:15:27.000Z&date2=2019-10-26T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({skills: Math.trunc(res[0].avg)}));
        fetch("http://localhost:3000/totalques?uid="+ this.state.student_id +"&date1=2019-09-24T19:15:27.000Z&date2=2019-10-26T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({prog: Math.trunc(res[0].sum * 1000)}));
        fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-09-24T19:15:27.000Z&date2=2019-10-26T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({study: Math.trunc(this.secondsToMinutes(res[0].avg))}));
    
    }

    overView(){
        fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-08-24T19:15:27.000Z&date2=2019-10-26T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({studyTime: [0, this.secondsToMinutes(res[0].avg)]}));
        fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-08-24T19:15:27.000Z&date2=2019-10-26T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({scores: [0, res[0].avg/100]}));
        fetch("http://localhost:3000/avgscore?uid="+ this.state.student_id +"&date1=2019-08-24T19:15:27.000Z&date2=2019-10-26T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({skills: Math.trunc(res[0].avg)}));
        fetch("http://localhost:3000/totalques?uid="+ this.state.student_id +"&date1=2019-08-24T19:15:27.000Z&date2=2019-10-26T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({prog: Math.trunc(res[0].sum * 100)}));
        fetch("http://localhost:3000/avgtime?uid="+ this.state.student_id +"&date1=2019-08-24T19:15:27.000Z&date2=2019-10-26T19:15:27.000Z").then(res=> res.json()).then(res => this.setState({study: Math.trunc(this.secondsToMinutes(res[0].avg))}));
        this.setState({
            atpq: [0,3]
        })
    }

    render() {

        /*
        sessions for studytime
        avgtime for avg
        score skills
        */
      
      
        
        const options = [];

        if(this.state.parents.length > 0) {
            this.state.parents.forEach(e => options.push(e.id));
        }

        const parent_id = "";
       // console.log("test", parent_id);

       // console.log("user: ", this.state.users);
        if(this.state.users.length > 0) {
            const name = this.state.users.forEach(e => {
                if(e.student_id == this.state.student_id){
                    this.state.setState({name: e.name});
                    return;
                }
            })

        }
        /*console.log("student: ", this.state.students);
        console.log("avgTime: ", this.state.atpq);
        console.log("studyTime: ", this.state.studyTime);
        console.log("scores: ", this.state.scores);
        console.log("parent: ", this.state.parents);
        console.log("name", this.state.name);
        */

        /*
        if(this.state.parents.length > 0){console.log("parent test:", this.state.parents[0].id);}
        */

        //console.log("pid", this.state.parent_id);

        /*
        if(this.state.students.length > 0) {
            console.log("here",this.state.students);
        }
        */
  

        const progressionLine = {
            labels: ["Last Week", "This Week"],
            datasets: [{
                label: "Progress Trend (% Completion)",
                backgroundColor: '#2A8BE4',
                borderColor: 'rgb(255, 99, 132)',
                data: this.state.scores,
            }],
            options: {
                responsive: true,
                maintainAspectRatio: true

            }

        }

        const studyTimeBar = {
            labels: ["Last Week", "This Week"],
            datasets: [{
                label: "Total Study Time (Hours)",
                backgroundColor: '#2A8BE4',
                borderColor: 'rgb(255, 99, 132)',
                data: this.state.studyTime,
            }],
            options: {
                responsive: true,
                maintainAspectRatio: true,

            }
        };

        const avgQuestionBar = {
            labels: ["Last Week", "This Week"],
            datasets: [{
                label: "Average Time per Question (Minutes)",
                backgroundColor: '#2A8BE4',
                borderColor: 'rgb(255, 99, 132)',
                data: this.state.atpq
            }]

        }

        return (

            <div className="container-fluid data" >
                <div className="row nv">
                    <nav id="upper_nav">
                        <div className="row">
                        <div className="col-lg-11 col-md-10 col-sm-10 col-10">
                            <div className="row">
                            <div className="d-block d-sm-none">
                                <a data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">
                                    <span className="glyphicon glyphicon-menu-hamburger sideButton"/>
                                </a>
                            </div>
                            <div>
                                <a className="logo" href="#" onClick ={this.overView}>Kato</a>
                            </div>
                        </div>
                        </div>
                        <div className="col-lg-1 col-md-2 col-sm-2 col-2 dropdown">
                            <a href="#" data-toggle="dropdown">
                                <span className="glyphicon glyphicon-user glyph-edit" aria-haspopup="true" aria-expanded="false" id="dropdownMenuButton"/>
                            </a>
                            <div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <a href= "\" className="dropdown-item">Parent</a>
                            </div>
                        </div>
                        </div>
                    </nav>
                </div>
                <div className="row bd">
                    <div className="col-lg-3 col-md-3 col-sm-6 navigation collapse multi-collapse" id="multiCollapseExample1">
                        <nav id="sidebar">
                            <div className="sidebar-header">
                                <h2>Reports History</h2>
                            </div>
                            <ul className="list-unstyled components">
                                <li>
                                    <a href="#" onClick ={this.changeWeek1}>This Week</a>
                                </li>
                                <li>
                                    <a href="#" onClick ={this.changeWeek2}>Last Week</a>
                                </li>
                                <li>
                                    <a href="#" onClick ={this.changeWeek3}>14 Oct - 20 Oct</a>
                                </li>
                                <li>
                                    <a href="#" onClick ={this.changeWeek4}>7 Oct - 13 Oct</a>
                                </li>
                                <li>
                                    <a href="#" onClick ={this.changeWeek5}>30 Sep - 6 Oct</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div className="col-lg-3 col-md-3 col-sm-6 navigation d-none d-sm-block">
                        <nav id="sidebar">
                            <div className="sidebar-header">
                                <h2>Reports History</h2>
                            </div>
                            <ul className="list-unstyled components">
                                <li>
                                    <a href="#" onClick ={this.changeWeek1}>This Week</a>
                                </li>
                                <li>
                                    <a href="#" onClick ={this.changeWeek2}>Last Week</a>
                                </li>
                                <li>
                                    <a href="#" onClick ={this.changeWeek3}>14 Oct - 20 Oct</a>
                                </li>
                                <li>
                                    <a href="#" onClick ={this.changeWeek4}>7 Oct - 13 Oct</a>
                                </li>
                                <li>
                                    <a href="#" onClick ={this.changeWeek5}>30 Sep - 6 Oct</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div className="col-lg-9 col-md-9 col-sm-6 col-12 dashboard">
                        <div className="info_head">
                            <h2> {this.state.name}'s Weekly Summary</h2>
                        </div>
                        <div className="col-lg-3 col-md-3 col-sm-3 info">
                            <a>Mastered in total</a>
                             <h1> {this.state.skills}% </h1>
                            <a>of the required skills</a>
                        </div>
                        <div className="col-lg-3 col-md-3 col-sm-3 info">
                            <a>Progressed by</a>
                            <h1> +{this.state.prog}% </h1>
                            <a>this week</a>
                        </div>
                        <div className="col-lg-3 col-md-3 col-sm-3 info">
                            <a>Total study time</a>
                            <h1> {this.state.study} hours </h1>
                        </div>
                        <div className="col-lg-3 col-md-3 col-sm-3 info">
                            <a>Avg time per question</a>
                            <h1> {this.state.avg} minutes  </h1>
                        </div>
                        <div className="col-lg-12 col-md-12 col-12 graphs">
                            <div className="col-lg-4 col-md-4 col-sm-4">
                                <Bar className = "studyTime" data ={studyTimeBar}/>
                            </div>
                            <div className="col-lg-4 col-md-4 col-sm-4">
                                <Line className = "progression" data = {progressionLine}/>
                            </div>
                            <div className="col-lg-4 col-md-4 col-sm-4">
                                <Bar className = "avgQuestion" data = {avgQuestionBar}/>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        );
    }

}
export default Info;